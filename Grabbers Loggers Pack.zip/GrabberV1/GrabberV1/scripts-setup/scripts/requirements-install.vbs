Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "pip install pyinstaller auto_py_to_exe", 0, True