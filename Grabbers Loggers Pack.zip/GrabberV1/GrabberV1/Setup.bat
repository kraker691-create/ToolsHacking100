:: Made by DominikPaste on pastebin.

@echo off
color 0A

echo [INFO] Installing Packages...
cscript //nologo scripts-setup/scripts/requirements-install.vbs

cls

set /p name=[INPUT] Enter File Name (.py): 

if not exist "%name%" (
    echo [ERROR] File not found: %name%
    pause
    exit /b
)

echo [INFO] Processing, Please Wait...

python -m PyInstaller --noconfirm --onefile --uac-admin --windowed "%name%" >nul 2>&1

rmdir /s /q "build" >nul 2>&1

if exist "dist" ren "dist" "Results"

echo [INFO/SUCCESS] Check Folder "Results"!
pause