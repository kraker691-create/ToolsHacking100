**Made by @dominikrbxofficial on Discord.**



**Please in file "Infected.py" change "WEBHOOK\_URL" to your webhook.**



**Then click Setup.bat . And exe file are created.**



**Please dont delete folder "scripts-setup".**

